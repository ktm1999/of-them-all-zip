import React, { useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from './utils';
import { Home, Sun, ShoppingBag, User } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const navItems = [
  { name: 'Space',   icon: Home,        page: 'Space'   },
  { name: 'Routine', icon: Sun,          page: 'Routine' },
  { name: 'Market',  icon: ShoppingBag,  page: 'Market'  },
  { name: 'Me',      icon: User,         page: 'Profile' },
];

// Root page for each tab – tapping an active tab navigates here
const TAB_ROOTS = {
  Space:   'Space',
  Routine: 'Routine',
  Market:  'Market',
  Profile: 'Profile',
};

const pageVariants = {
  initial: { opacity: 0, x: 24 },
  animate: { opacity: 1, x: 0 },
  exit:    { opacity: 0, x: -24 },
};
const pageTransition = { duration: 0.22, ease: 'easeInOut' };

export default function Layout({ children, currentPageName }) {
  const navigate  = useNavigate();

  const hideNav = ['Onboarding', 'Player', 'Cart', 'ProductDetail',
    'InstantRitual', 'ScheduleRitual', 'RitualDetail'].includes(currentPageName);

  // Which top-level tab is "active"
  const activeTab = navItems.find(n => n.page === currentPageName)?.page
    ?? (currentPageName === 'Collections' || currentPageName === 'Goals'
        || currentPageName === 'Account'  || currentPageName === 'Orders'
        || currentPageName === 'Membership' || currentPageName === 'HelpCenter'
        ? 'Profile' : null)
    ?? (currentPageName === 'RitualDetail' || currentPageName === 'Player'
        || currentPageName === 'InstantRitual' || currentPageName === 'ScheduleRitual'
        ? 'Routine' : null)
    ?? (currentPageName === 'ProductDetail' || currentPageName === 'Cart'
        ? 'Market' : null)
    ?? 'Space';

  const handleTabPress = (item) => {
    if (activeTab === item.page) {
      // Reset to root of this tab
      navigate(createPageUrl(TAB_ROOTS[item.page]), { replace: true });
    } else {
      navigate(createPageUrl(item.page));
    }
  };

  return (
    <div
      className="min-h-screen dark:bg-[#121212] flex flex-col select-none"
      style={{
        background: 'linear-gradient(to bottom, rgba(237,233,254,0.5), white, rgba(252,231,243,0.3))',
        paddingTop: 'env(safe-area-inset-top)',
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap');

        :root {
          --color-primary: #3F5947;
          --color-primary-hover: #35483A;
          --color-text-dark: #2C2C2C;
          --color-text-gray: #6B6B6B;
          --color-text-light: #8B8B8B;
          --color-border: #D0D0D0;
          --color-bg-gray: #F5F5F5;
          --color-accent-orange: #FF7A5C;
          --color-selected: #D4D0D4;
          --color-surface: #FFFFFF;
          --color-surface-alt: #F5F5F5;
        }

        @media (prefers-color-scheme: dark) {
          :root {
            --color-primary: #6CA882;
            --color-primary-hover: #5A9470;
            --color-text-dark: #F0F0F0;
            --color-text-gray: #A0A0A0;
            --color-text-light: #707070;
            --color-border: #3A3A3A;
            --color-bg-gray: #1E1E1E;
            --color-accent-orange: #FF9B7A;
            --color-selected: #3A3A3A;
            --color-surface: #1E1E1E;
            --color-surface-alt: #2A2A2A;
          }
          body { background-color: #121212; color: #F0F0F0; }
        }

        .font-serif { font-family: 'Playfair Display', serif; }
        .font-sans  { font-family: 'Inter', sans-serif; }

        body {
          font-family: 'Inter', sans-serif;
          overscroll-behavior: none;
          -webkit-tap-highlight-color: transparent;
        }

        * { -webkit-overflow-scrolling: touch; }
      `}</style>

      <main
        className="flex-1"
        style={{ paddingBottom: !hideNav ? 'calc(4rem + env(safe-area-inset-bottom))' : undefined }}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPageName}
            variants={pageVariants}
            initial="initial"
            animate="animate"
            exit="exit"
            transition={pageTransition}
            className="h-full"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </main>

      {!hideNav && (
        <nav
          className="fixed bottom-0 left-0 right-0 bg-white dark:bg-[#1E1E1E] border-t border-gray-200 dark:border-gray-800 flex items-center justify-around px-4 z-50"
          style={{
            height: 'calc(4rem + env(safe-area-inset-bottom))',
            paddingBottom: 'env(safe-area-inset-bottom)',
          }}
        >
          {navItems.map((item) => {
            const isActive = activeTab === item.page;
            const Icon = item.icon;

            return (
              <button
                key={item.name}
                onClick={() => handleTabPress(item)}
                className={`flex flex-col items-center gap-1 py-2 px-4 transition-colors select-none ${
                  isActive ? 'text-[#2C2C2C] dark:text-white' : 'text-[#8B8B8B] dark:text-gray-500'
                }`}
              >
                <Icon className="w-6 h-6" strokeWidth={isActive ? 2 : 1.5} />
                <span className={`text-xs ${isActive ? 'font-semibold' : 'font-medium'}`}>
                  {item.name}
                </span>
              </button>
            );
          })}
        </nav>
      )}
    </div>
  );
}