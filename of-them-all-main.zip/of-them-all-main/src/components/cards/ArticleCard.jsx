import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function ArticleCard({ content, onClick }) {
  const gradientStart = content.gradient_start || '#E8D9F0';
  const gradientEnd = content.gradient_end || '#D4C4E8';
  
  return (
    <div 
      className="rounded-2xl overflow-hidden shadow-sm cursor-pointer transition-all duration-200 hover:shadow-md"
      onClick={onClick}
      style={{ background: `linear-gradient(135deg, ${gradientStart}, ${gradientEnd})` }}
    >
      <div className="p-6">
        <span className="inline-block px-3 py-1 bg-white/80 rounded-full text-xs font-semibold text-gray-600 mb-4">
          WIKI
        </span>
        
        <h3 className="font-serif text-xl text-[#2C2C2C] mb-3">
          {content.title}
        </h3>
        
        <p className="text-[#6B6B6B] text-sm leading-relaxed mb-4">
          {content.description}
        </p>
        
        <button className="flex items-center gap-2 text-[#2C2C2C] font-medium text-sm hover:gap-3 transition-all">
          Continue Reading <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}