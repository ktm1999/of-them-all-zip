import React from 'react';

export default function QuoteCard({ content, onClick }) {
  const gradientStart = content.gradient_start || '#FF9B7A';
  const gradientEnd = content.gradient_end || '#FFD4B8';
  
  return (
    <div 
      className="rounded-2xl overflow-hidden shadow-sm cursor-pointer transition-all duration-200 hover:shadow-md"
      onClick={onClick}
      style={{ background: `linear-gradient(135deg, ${gradientStart}, ${gradientEnd})` }}
    >
      <div className="p-8 min-h-[280px] flex items-center justify-center">
        <p className="font-serif text-lg text-[#2C2C2C] text-center leading-relaxed">
          {content.quote_text || content.description}
        </p>
      </div>
    </div>
  );
}