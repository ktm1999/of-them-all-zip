import React from 'react';
import { Play } from 'lucide-react';

export default function ContentCard({ 
  content, 
  onClick, 
  onPlayClick,
  showPlayButton = true 
}) {
  const gradientStart = content.gradient_start || '#F4B084';
  const gradientEnd = content.gradient_end || '#FDD9C4';
  
  return (
    <div 
      className="rounded-2xl overflow-hidden shadow-sm cursor-pointer transition-all duration-200 hover:shadow-md hover:scale-[1.01] active:scale-[0.99]"
      onClick={onClick}
    >
      {/* Gradient Area */}
      <div 
        className="h-44 relative flex items-center justify-center"
        style={{ background: `linear-gradient(135deg, ${gradientStart}, ${gradientEnd})` }}
      >
        {/* Meditation Icon */}
        <svg 
          viewBox="0 0 64 64" 
          className="w-20 h-20 text-white/90"
          fill="currentColor"
        >
          <circle cx="32" cy="16" r="8" />
          <path d="M20 52 Q32 44 44 52 L48 58 Q32 50 16 58 Z" />
          <ellipse cx="32" cy="36" rx="12" ry="8" />
        </svg>
        
        {/* Play Button */}
        {showPlayButton && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onPlayClick?.();
            }}
            className="absolute bottom-4 right-4 w-14 h-14 bg-white/90 rounded-full flex items-center justify-center shadow-lg hover:bg-white transition-colors"
          >
            <Play className="w-6 h-6 text-gray-600 ml-1" fill="currentColor" />
          </button>
        )}
      </div>
      
      {/* Info Bar */}
      <div className="bg-white p-4">
        <p className="text-sm text-gray-500 mb-1">
          {content.type?.charAt(0).toUpperCase() + content.type?.slice(1)} · {content.duration_minutes} min
        </p>
        <h3 className="font-serif text-xl text-[#2C2C2C]">{content.title}</h3>
      </div>
    </div>
  );
}