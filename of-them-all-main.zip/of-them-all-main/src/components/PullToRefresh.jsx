import React, { useRef, useState, useCallback } from 'react';

const THRESHOLD = 70;

export default function PullToRefresh({ onRefresh, children }) {
  const [pulling, setPulling] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startY = useRef(null);
  const containerRef = useRef(null);

  const handleTouchStart = useCallback((e) => {
    const scrollTop = containerRef.current?.scrollTop ?? 0;
    if (scrollTop === 0) {
      startY.current = e.touches[0].clientY;
    }
  }, []);

  const handleTouchMove = useCallback((e) => {
    if (startY.current === null || refreshing) return;
    const currentY = e.touches[0].clientY;
    const distance = Math.max(0, currentY - startY.current);
    if (distance > 0) {
      setPulling(true);
      setPullDistance(Math.min(distance * 0.5, THRESHOLD * 1.2));
    }
  }, [refreshing]);

  const handleTouchEnd = useCallback(async () => {
    if (pullDistance >= THRESHOLD) {
      setRefreshing(true);
      setPullDistance(THRESHOLD * 0.6);
      await onRefresh?.();
      setRefreshing(false);
    }
    startY.current = null;
    setPulling(false);
    setPullDistance(0);
  }, [pullDistance, onRefresh]);

  const progress = Math.min(pullDistance / THRESHOLD, 1);
  const showIndicator = pulling || refreshing;

  return (
    <div
      ref={containerRef}
      className="relative overflow-y-auto h-full"
      style={{ overscrollBehavior: 'none' }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Pull indicator */}
      <div
        className="flex items-center justify-center transition-all duration-200 pointer-events-none"
        style={{ height: showIndicator ? `${pullDistance}px` : 0, overflow: 'hidden' }}
      >
        <div
          className="w-8 h-8 rounded-full border-2 border-[#3F5947] border-t-transparent"
          style={{
            animation: refreshing ? 'spin 0.8s linear infinite' : 'none',
            transform: refreshing ? undefined : `rotate(${progress * 270}deg)`,
            opacity: progress,
          }}
        />
      </div>
      {children}
    </div>
  );
}