import React, { useState } from 'react';
import { Drawer } from 'vaul';
import { Check, ChevronDown } from 'lucide-react';

/**
 * Drop-in replacement for Shadcn <Select> that renders a bottom-sheet
 * drawer on mobile and a native-style list on all screens.
 *
 * Props mirror a simplified Select API:
 *   value, onValueChange, placeholder, options: [{ value, label }]
 */
export default function MobileSelect({ value, onValueChange, placeholder = 'Select…', options = [], className = '' }) {
  const [open, setOpen] = useState(false);

  const selected = options.find(o => o.value === value);

  const handleSelect = (val) => {
    onValueChange?.(val);
    setOpen(false);
  };

  return (
    <Drawer.Root open={open} onOpenChange={setOpen}>
      <Drawer.Trigger asChild>
        <button
          type="button"
          className={`flex items-center justify-between gap-2 px-4 py-3 rounded-full bg-gray-100 dark:bg-[#2A2A2A] text-sm font-medium text-[#2C2C2C] dark:text-[#F0F0F0] border border-transparent focus:outline-none ${className}`}
        >
          <span className={selected ? '' : 'text-gray-400'}>
            {selected ? selected.label : placeholder}
          </span>
          <ChevronDown className="w-4 h-4 text-gray-400 flex-shrink-0" />
        </button>
      </Drawer.Trigger>

      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/40 z-50" />
        <Drawer.Content
          className="fixed bottom-0 left-0 right-0 z-50 flex flex-col bg-white dark:bg-[#1E1E1E] rounded-t-3xl outline-none"
          style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
        >
          {/* Handle */}
          <div className="flex justify-center pt-3 pb-2">
            <div className="w-10 h-1 rounded-full bg-gray-300 dark:bg-gray-600" />
          </div>

          {/* Options */}
          <div className="overflow-y-auto max-h-[60vh] px-4 pb-4">
            {options.map((opt) => {
              const isSelected = opt.value === value;
              return (
                <button
                  key={opt.value}
                  onClick={() => handleSelect(opt.value)}
                  className={`w-full flex items-center justify-between px-4 py-4 rounded-xl mb-1 transition-colors text-left ${
                    isSelected
                      ? 'bg-gray-100 dark:bg-[#2A2A2A] font-semibold text-[#2C2C2C] dark:text-white'
                      : 'hover:bg-gray-50 dark:hover:bg-[#2A2A2A] text-[#2C2C2C] dark:text-[#F0F0F0]'
                  }`}
                >
                  <span>{opt.label}</span>
                  {isSelected && <Check className="w-4 h-4 text-[#3F5947]" />}
                </button>
              );
            })}
          </div>
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}