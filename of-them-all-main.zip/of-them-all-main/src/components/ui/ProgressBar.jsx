import React from 'react';

export default function ProgressBar({ currentStep, totalSteps = 5 }) {
  const labels = ['Welcome', '', 'Check-in', '', 'Begin'];
  
  return (
    <div className="flex flex-col items-center gap-2">
      <div className="flex gap-2">
        {Array.from({ length: totalSteps }).map((_, index) => (
          <div
            key={index}
            className={`h-1 w-12 rounded-full transition-colors ${
              index < currentStep ? 'bg-[#8B7D8F]' : 'bg-gray-200'
            }`}
          />
        ))}
      </div>
      <div className="flex justify-between w-full px-2">
        <span className="text-xs text-gray-500">{labels[0]}</span>
        <span className="text-xs text-gray-500">{labels[2]}</span>
        <span className="text-xs text-gray-500">{labels[4]}</span>
      </div>
    </div>
  );
}