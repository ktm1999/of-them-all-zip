import React from 'react';

export default function PrimaryButton({ 
  children, 
  onClick, 
  disabled = false,
  variant = 'primary',
  fullWidth = true,
  icon: Icon,
  className = ''
}) {
  const baseClasses = `
    py-4 px-6 rounded-full font-semibold text-lg transition-all duration-200
    flex items-center justify-center gap-2
    ${fullWidth ? 'w-full' : ''}
    active:scale-[0.98]
  `;
  
  const variants = {
    primary: `bg-[#3F5947] text-white hover:bg-[#35483A] ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`,
    secondary: 'bg-white border-2 border-[#3F5947] text-[#3F5947] hover:bg-gray-50',
    outline: 'bg-white border-2 border-[#2C2C2C] text-[#2C2C2C] hover:bg-gray-50',
    gray: 'bg-[#D4D0D4] text-[#2C2C2C]',
  };
  
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseClasses} ${variants[variant]} ${className}`}
    >
      {Icon && <Icon className="w-5 h-5" />}
      {children}
    </button>
  );
}