import React from 'react';

export default function SelectionPill({ 
  label, 
  selected, 
  onClick, 
  emoji,
  fullWidth = false,
  size = 'default'
}) {
  return (
    <button
      onClick={onClick}
      className={`
        ${fullWidth ? 'w-full' : 'inline-flex'}
        ${size === 'small' ? 'py-2 px-4 text-sm' : 'py-4 px-6 text-base'}
        rounded-full font-medium transition-all duration-200
        ${selected 
          ? 'bg-[#D4D0D4] text-[#2C2C2C]' 
          : 'bg-white border border-gray-300 text-[#6B6B6B] hover:border-gray-400'
        }
        flex items-center justify-center gap-2
      `}
    >
      {emoji && <span>{emoji}</span>}
      {label}
    </button>
  );
}