/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Account from './pages/Account';
import Cart from './pages/Cart';
import Collections from './pages/Collections';
import Goals from './pages/Goals';
import HelpCenter from './pages/HelpCenter';
import InstantRitual from './pages/InstantRitual';
import Market from './pages/Market';
import Membership from './pages/Membership';
import Onboarding from './pages/Onboarding';
import Orders from './pages/Orders';
import Player from './pages/Player';
import ProductDetail from './pages/ProductDetail';
import Profile from './pages/Profile';
import RitualDetail from './pages/RitualDetail';
import Routine from './pages/Routine';
import ScheduleRitual from './pages/ScheduleRitual';
import Space from './pages/Space';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Account": Account,
    "Cart": Cart,
    "Collections": Collections,
    "Goals": Goals,
    "HelpCenter": HelpCenter,
    "InstantRitual": InstantRitual,
    "Market": Market,
    "Membership": Membership,
    "Onboarding": Onboarding,
    "Orders": Orders,
    "Player": Player,
    "ProductDetail": ProductDetail,
    "Profile": Profile,
    "RitualDetail": RitualDetail,
    "Routine": Routine,
    "ScheduleRitual": ScheduleRitual,
    "Space": Space,
}

export const pagesConfig = {
    mainPage: "Onboarding",
    Pages: PAGES,
    Layout: __Layout,
};