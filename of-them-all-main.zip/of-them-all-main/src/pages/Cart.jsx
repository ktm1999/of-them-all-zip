import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { X, Minus, Plus } from 'lucide-react';
import PrimaryButton from '@/components/ui/PrimaryButton';

export default function Cart() {
  const navigate = useNavigate();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    loadCart();
  }, []);
  
  const loadCart = async () => {
    const data = await base44.entities.CartItem.list();
    setItems(data);
    setLoading(false);
  };
  
  const updateQuantity = async (item, delta) => {
    const newQuantity = (item.quantity || 1) + delta;

    // Optimistic update
    if (newQuantity <= 0) {
      setItems(prev => prev.filter(i => i.id !== item.id));
      await base44.entities.CartItem.delete(item.id);
    } else {
      setItems(prev => prev.map(i => i.id === item.id ? { ...i, quantity: newQuantity } : i));
      await base44.entities.CartItem.update(item.id, { quantity: newQuantity });
    }
  };
  
  const subtotal = items.reduce((sum, item) => 
    sum + (item.product_price || 0) * (item.quantity || 1), 0
  );

  return (
    <div
      className="min-h-screen bg-white dark:bg-[#121212] flex flex-col"
      style={{
        paddingTop: 'calc(1.5rem + env(safe-area-inset-top))',
        paddingBottom: 'calc(1.5rem + env(safe-area-inset-bottom))',
        paddingLeft: '1.5rem',
        paddingRight: '1.5rem',
      }}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button onClick={() => navigate(-1)}>
          <X className="w-6 h-6" />
        </button>
        <h1 className="font-serif text-2xl text-[#2C2C2C]">Cart</h1>
        <div className="w-6" />
      </div>
      
      {/* Promo Banner */}
      <div className="bg-orange-50 rounded-xl p-4 mb-6">
        <p className="text-sm text-gray-700">
          💥 FLASH HOLIDAY SALE - Use code <strong>OFTHEMALL25</strong> for 25% off site-wide and free shipping for a limited time only.
        </p>
      </div>
      
      {/* Cart Items */}
      <div className="flex-1">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-12">
            <p className="font-serif text-xl text-gray-400">Cart is empty</p>
          </div>
        ) : (
          <div className="space-y-4">
            {items.map((item) => (
              <div key={item.id} className="flex gap-4">
                {/* Product Image */}
                <div className="w-24 h-24 bg-gradient-to-br from-purple-100 to-pink-50 rounded-xl flex-shrink-0 flex items-center justify-center">
                  <div className="w-16 h-16 bg-white rounded-lg shadow-sm" />
                </div>
                
                {/* Product Info */}
                <div className="flex-1">
                  <h3 className="font-serif text-lg text-[#2C2C2C]">{item.product_name}</h3>
                  <p className="text-sm text-gray-500 line-clamp-2">
                    • 4 Glowing & lifting sheet masks<br />
                    • 4 Cooling & calming shee...
                  </p>
                  
                  {/* Quantity Controls */}
                  <div className="flex items-center gap-4 mt-3">
                    <button
                      onClick={() => updateQuantity(item, -1)}
                      className="w-10 h-10 rounded-full bg-[#FF7A5C] flex items-center justify-center"
                    >
                      <Minus className="w-5 h-5 text-white" />
                    </button>
                    <span className="font-semibold text-lg">{item.quantity || 1}</span>
                    <button
                      onClick={() => updateQuantity(item, 1)}
                      className="w-10 h-10 rounded-full bg-[#FF7A5C] flex items-center justify-center"
                    >
                      <Plus className="w-5 h-5 text-white" />
                    </button>
                    <span className="font-serif text-lg ml-auto">
                      ${((item.product_price || 0) * (item.quantity || 1)).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Subtotal & Checkout */}
      {items.length > 0 && (
        <div className="mt-auto pt-6">
          <div className="flex justify-between items-center mb-4">
            <span className="text-gray-500">Subtotal:</span>
            <span className="font-serif text-xl">${subtotal.toFixed(2)}</span>
          </div>
          
          <PrimaryButton onClick={() => alert('Checkout functionality would go here')}>
            Checkout
          </PrimaryButton>
        </div>
      )}
    </div>
  );
}