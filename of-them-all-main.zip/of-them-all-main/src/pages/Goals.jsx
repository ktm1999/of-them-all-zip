import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Sparkles } from 'lucide-react';
import PrimaryButton from '@/components/ui/PrimaryButton';

export default function Goals() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [routineCount, setRoutineCount] = useState(0);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    loadData();
  }, []);
  
  const loadData = async () => {
    const [profiles, routines] = await Promise.all([
      base44.entities.UserProfile.list(),
      base44.entities.Routine.list()
    ]);
    
    if (profiles.length > 0) {
      setProfile(profiles[0]);
    }
    setRoutineCount(routines.length);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-50 via-purple-50/30 to-white p-6 flex flex-col">
      {/* Header */}
      <button onClick={() => navigate(-1)} className="mb-8">
        <ArrowLeft className="w-6 h-6 text-[#3F5947]" />
      </button>
      
      {/* Compass Icon */}
      <div className="flex justify-center mb-8">
        <div className="w-32 h-32 relative">
          <svg viewBox="0 0 100 100" className="w-full h-full text-[#2C3E50]">
            <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="2 4" />
            <circle cx="50" cy="50" r="35" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="1 3" />
            {/* Compass points */}
            <path d="M50 10 L55 45 L50 35 L45 45 Z" fill="currentColor" />
            <path d="M50 90 L55 55 L50 65 L45 55 Z" fill="currentColor" opacity="0.5" />
            <path d="M10 50 L45 55 L35 50 L45 45 Z" fill="currentColor" opacity="0.5" />
            <path d="M90 50 L55 55 L65 50 L55 45 Z" fill="currentColor" opacity="0.5" />
          </svg>
        </div>
      </div>
      
      {/* Title */}
      <h1 className="font-serif text-3xl text-center text-[#2C2C2C] mb-8">
        My goal.<br />My steps of becoming.
      </h1>
      
      {/* Goal Cards */}
      <div className="space-y-4 flex-1">
        <div className="bg-gray-50 rounded-2xl p-5">
          <div className="flex items-start gap-4">
            <Sparkles className="w-6 h-6 text-gray-600 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-[#2C2C2C] mb-2">My Target</h3>
              <p className="text-gray-500">
                {profile?.intentions?.join(', ') || 'No goals set yet'}
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 rounded-2xl p-5">
          <div className="flex items-start gap-4">
            <span className="text-2xl">∞</span>
            <div>
              <h3 className="font-semibold text-[#2C2C2C] mb-2">My Ritual</h3>
              <p className="text-gray-500">
                A 3-month long routine that includes {routineCount || 0} events.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Update Button */}
      <div className="mt-auto pt-6">
        <PrimaryButton onClick={() => navigate(createPageUrl('Onboarding') + '?edit=true')}>
          Update Goal
        </PrimaryButton>
      </div>
    </div>
  );
}