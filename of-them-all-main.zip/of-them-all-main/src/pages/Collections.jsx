import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Play } from 'lucide-react';

const TABS = [
  { key: 'liked', label: 'Liked' },
  { key: 'downloaded', label: 'Downloaded' },
  { key: 'recent', label: 'Recently Viewed' },
];

export default function Collections() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('liked');
  const [collections, setCollections] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    loadCollections();
  }, [activeTab]);
  
  const loadCollections = async () => {
    setLoading(true);
    const data = await base44.entities.Collection.filter({ 
      collection_type: activeTab 
    });
    setCollections(data);
    setLoading(false);
  };

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <button onClick={() => navigate(-1)} className="mb-4">
        <ArrowLeft className="w-6 h-6 text-[#3F5947]" />
      </button>
      
      <h1 className="font-serif text-3xl text-[#2C2C2C] mb-6">Collections</h1>
      
      {/* Tabs */}
      <div className="flex border-b border-gray-200 mb-6">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`py-3 px-4 text-sm font-medium transition-colors relative ${
              activeTab === tab.key 
                ? 'text-[#2C2C2C]' 
                : 'text-gray-400'
            }`}
          >
            {tab.label}
            {activeTab === tab.key && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#2C2C2C]" />
            )}
          </button>
        ))}
      </div>
      
      {/* Content */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
        </div>
      ) : collections.length === 0 ? (
        <div className="text-center py-12 text-gray-400">
          No items in this collection yet
        </div>
      ) : (
        <div className="space-y-4">
          {collections.map((item) => (
            <div
              key={item.id}
              onClick={() => navigate(createPageUrl('RitualDetail') + `?id=${item.content_id}`)}
              className="rounded-2xl overflow-hidden cursor-pointer"
            >
              <div 
                className="h-36 relative flex items-center justify-center"
                style={{ 
                  background: `linear-gradient(135deg, ${item.content_gradient_start || '#6B5B7F'}, ${item.content_gradient_end || '#4A5F7A'})` 
                }}
              >
                <svg 
                  viewBox="0 0 64 64" 
                  className="w-16 h-16 text-white/70"
                  fill="currentColor"
                >
                  <circle cx="32" cy="16" r="6" />
                  <path d="M20 48 Q32 42 44 48 L46 52 Q32 46 18 52 Z" />
                  <ellipse cx="32" cy="34" rx="10" ry="7" />
                </svg>
                
                <button className="absolute bottom-4 right-4 w-12 h-12 bg-white/80 rounded-full flex items-center justify-center">
                  <Play className="w-5 h-5 text-gray-600 ml-0.5" fill="currentColor" />
                </button>
              </div>
              
              <div className="bg-white p-4">
                <p className="text-sm text-gray-500 mb-1">
                  {item.content_type?.charAt(0).toUpperCase() + item.content_type?.slice(1)} · {item.content_duration} min
                </p>
                <h3 className="font-serif text-lg text-[#2C2C2C]">{item.content_title}</h3>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}