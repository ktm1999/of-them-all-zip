import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { ShoppingBag, Sparkles } from 'lucide-react';
import PrimaryButton from '@/components/ui/PrimaryButton';

export default function Market() {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cartCount, setCartCount] = useState(0);
  const scrollRef = useRef(null);
  
  useEffect(() => {
    loadData();
  }, []);
  
  const loadData = async () => {
    const [productsData, cartData] = await Promise.all([
      base44.entities.Product.list(),
      base44.entities.CartItem.list()
    ]);
    
    setProducts(productsData);
    setCartCount(cartData.reduce((sum, item) => sum + (item.quantity || 1), 0));
    setLoading(false);
  };
  
  const handlePurchase = (product) => {
    navigate(createPageUrl('ProductDetail') + `?id=${product.id}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Default products if none exist
  const displayProducts = products.length > 0 ? products : [
    {
      id: 'bi-weekly',
      name: 'BI-WEEKLY BUNDLE',
      price: 49.99,
      type: 'bundle',
      benefits: [
        '4 Glowing & lifting sheet masks',
        '4 Cooling & calming sheet masks',
        '14-day free trial + 30-day complimentary membership'
      ],
      gradient_start: '#D8DFE4',
      gradient_end: '#E8EEF2'
    },
    {
      id: 'monthly',
      name: 'MONTHLY BUNDLE',
      price: 79.99,
      type: 'bundle',
      benefits: [
        '9 Glowing & lifting sheet masks',
        '9 Cooling & calming sheet masks',
        '14-day free trial + 60-day complimentary membership'
      ],
      gradient_start: '#F4F0E8',
      gradient_end: '#FAF6EE'
    },
    {
      id: 'membership',
      name: 'APP MEMBERSHIP',
      price: 19.99,
      type: 'membership',
      description: 'Tap into a 3-month of mind-centering, mood-boosting, glow-up energy — anytime you need it',
      gradient_start: '#D8E8F0',
      gradient_end: '#E8F2F8'
    },
    {
      id: 'explore',
      name: 'SUBSCRIBE & EXPLORE',
      type: 'explore',
      description: 'Subscribe to our membership plan and explore app freely',
      gradient_start: '#F4E8F8',
      gradient_end: '#FAF0FC'
    }
  ];

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-serif text-3xl text-[#2C2C2C]">Shop</h1>
        <button 
          onClick={() => navigate(createPageUrl('Cart'))}
          className="w-12 h-12 bg-[#3F5947] rounded-full flex items-center justify-center relative"
        >
          <ShoppingBag className="w-5 h-5 text-white" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </button>
      </div>
      
      {/* Product Carousel */}
      <div className="space-y-6">
        {displayProducts.map((product) => (
          <div
            key={product.id}
            className="rounded-3xl overflow-hidden"
            style={{ 
              background: `linear-gradient(135deg, ${product.gradient_start || '#E8E8E8'}, ${product.gradient_end || '#F0F0F0'})` 
            }}
          >
            <div className="p-8 text-center">
              <h2 className="font-serif text-2xl text-[#2C2C2C] mb-4">{product.name}</h2>
              
              {product.benefits && (
                <ul className="text-sm text-gray-600 space-y-2 mb-4">
                  {product.benefits.map((benefit, i) => (
                    <li key={i}>• {benefit}</li>
                  ))}
                </ul>
              )}
              
              {product.description && (
                <p className="text-sm text-gray-600 mb-4">{product.description}</p>
              )}
              
              {product.price && (
                <p className="font-serif text-2xl text-[#2C2C2C] mb-6">
                  ${product.price}{product.type === 'membership' ? ' / 3 months' : ''}
                </p>
              )}
              
              {/* Product Image Placeholder */}
              {product.type === 'bundle' && (
                <div className="w-40 h-40 mx-auto mb-6 bg-white/50 rounded-xl flex items-center justify-center">
                  <div className="w-32 h-32 bg-gradient-to-br from-purple-200 to-orange-200 rounded-lg transform rotate-12" />
                </div>
              )}
              
              {product.type === 'explore' && (
                <div className="flex justify-center gap-2 mb-6">
                  <Sparkles className="w-12 h-12 text-pink-300" />
                  <Sparkles className="w-8 h-8 text-orange-300" />
                </div>
              )}
              
              <PrimaryButton
                onClick={() => handlePurchase(product)}
                variant={product.type === 'explore' ? 'secondary' : 'primary'}
                fullWidth={false}
                className="px-12"
              >
                {product.type === 'explore' ? 'Explore Our Membership' : 'Purchase'}
              </PrimaryButton>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}