import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Pause, Play } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Player() {
  const navigate = useNavigate();
  const [content, setContent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isPlaying, setIsPlaying] = useState(true);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [sessionId, setSessionId] = useState(null);
  const intervalRef = useRef(null);
  
  useEffect(() => {
    loadContent();
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);
  
  const loadContent = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const contentId = urlParams.get('id');
    
    if (contentId) {
      const contentList = await base44.entities.Content.filter({ id: contentId });
      if (contentList.length > 0) {
        const contentItem = contentList[0];
        setContent(contentItem);
        setTimeRemaining(contentItem.duration_minutes * 60);
        
        // Create session
        const session = await base44.entities.Session.create({
          content_id: contentId,
          content_title: contentItem.title,
          started_at: new Date().toISOString(),
          source: 'browse',
          completed: false,
          duration_played: 0
        });
        setSessionId(session.id);
        
        // Start timer
        startTimer();
      }
    }
    setLoading(false);
  };
  
  const startTimer = () => {
    intervalRef.current = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(intervalRef.current);
          handleComplete();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };
  
  const togglePlay = () => {
    if (isPlaying) {
      clearInterval(intervalRef.current);
    } else {
      startTimer();
    }
    setIsPlaying(!isPlaying);
  };
  
  const handleComplete = async () => {
    if (sessionId) {
      await base44.entities.Session.update(sessionId, {
        completed_at: new Date().toISOString(),
        completed: true,
        duration_played: content.duration_minutes * 60
      });
    }
    navigate(createPageUrl('Space'));
  };
  
  const handleBack = async () => {
    if (sessionId && content) {
      const playedSeconds = (content.duration_minutes * 60) - timeRemaining;
      await base44.entities.Session.update(sessionId, {
        duration_played: playedSeconds,
        completed: false
      });
    }
    navigate(-1);
  };
  
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <div
        className="min-h-screen bg-[#3D4A5C] flex items-center justify-center"
        style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-gradient-to-b from-[#3D4A5C] to-[#2C3542] flex flex-col items-center justify-center p-6"
      style={{ paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="text-white"
        style={{ position: 'absolute', top: 'calc(1.5rem + env(safe-area-inset-top))', left: '1.5rem' }}
      >
        <ArrowLeft className="w-6 h-6" />
      </button>
      
      {/* Breathing Orb */}
      <motion.div
        animate={{
          scale: isPlaying ? [1, 1.1, 1] : 1,
        }}
        transition={{
          duration: 4,
          repeat: isPlaying ? Infinity : 0,
          ease: 'easeInOut'
        }}
        className="w-48 h-48 rounded-full mb-16"
        style={{
          background: 'radial-gradient(circle, #FFB88C 0%, #FF8866 50%, transparent 70%)',
          filter: 'blur(20px)',
        }}
      />
      
      {/* Timer */}
      <div className="text-white text-6xl font-light font-serif mb-4">
        {formatTime(timeRemaining)}
      </div>
      
      {/* Title */}
      <p className="text-white/80 text-lg font-serif mb-12">
        {content?.title}
      </p>
      
      {/* Play/Pause Button */}
      <button
        onClick={togglePlay}
        className="w-16 h-16 rounded-full bg-white/20 border-2 border-white flex items-center justify-center"
      >
        {isPlaying ? (
          <Pause className="w-6 h-6 text-white" fill="white" />
        ) : (
          <Play className="w-6 h-6 text-white ml-1" fill="white" />
        )}
      </button>
    </div>
  );
}