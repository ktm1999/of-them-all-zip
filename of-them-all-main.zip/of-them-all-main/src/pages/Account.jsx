import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ArrowLeft } from 'lucide-react';
import PrimaryButton from '@/components/ui/PrimaryButton';

export default function Account() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    loadUser();
  }, []);
  
  const loadUser = async () => {
    try {
      const userData = await base44.auth.me();
      setUser(userData);
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };
  
  const getInitial = () => {
    if (user?.full_name) {
      return user.full_name.charAt(0).toUpperCase();
    }
    if (user?.email) {
      return user.email.charAt(0).toUpperCase();
    }
    return 'U';
  };
  
  const getDisplayName = () => {
    if (user?.full_name) {
      const parts = user.full_name.split(' ');
      if (parts.length > 1) {
        return `${parts[0]} ${parts[1].charAt(0)}.`;
      }
      return user.full_name;
    }
    return 'User';
  };
  
  const handleLogout = async () => {
    await base44.auth.logout();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 flex flex-col">
      {/* Header */}
      <button onClick={() => navigate(-1)} className="mb-8">
        <ArrowLeft className="w-6 h-6 text-[#3F5947]" />
      </button>
      
      {/* Avatar */}
      <div className="flex flex-col items-center mb-10">
        <div className="w-24 h-24 rounded-full bg-[#C8D5C8] flex items-center justify-center mb-4">
          <span className="text-white font-serif text-4xl">{getInitial()}</span>
        </div>
        <h1 className="font-serif text-2xl text-[#2C2C2C]">{getDisplayName()}</h1>
      </div>
      
      {/* Login Details */}
      <div className="mb-8">
        <h2 className="text-sm text-gray-400 mb-2">Login Details</h2>
        <p className="text-gray-500">{user?.email}</p>
      </div>
      
      {/* Account Management */}
      <div className="mb-8">
        <h2 className="text-sm text-gray-400 mb-2">Account Management</h2>
        <button className="text-red-500 font-medium">Delete Account</button>
      </div>
      
      {/* Logout */}
      <div className="mt-auto">
        <PrimaryButton onClick={handleLogout} variant="outline">
          Logout
        </PrimaryButton>
      </div>
    </div>
  );
}