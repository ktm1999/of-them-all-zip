import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Pencil, Plus, Zap, CalendarPlus } from 'lucide-react';
import PullToRefresh from '@/components/PullToRefresh';
import { format, addDays, startOfWeek, isSameDay, parseISO } from 'date-fns';

export default function Routine() {
  const navigate = useNavigate();
  const [routines, setRoutines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showModal, setShowModal] = useState(false);
  
  const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  
  useEffect(() => {
    loadRoutines();
  }, []);
  
  const loadRoutines = async () => {
    const data = await base44.entities.Routine.list('-scheduled_date');
    setRoutines(data);
    setLoading(false);
  };
  
  const getRoutinesForDate = (date) => {
    return routines.filter(r => {
      if (!r.scheduled_date) return false;
      return isSameDay(parseISO(r.scheduled_date), date);
    });
  };
  
  const getStatusText = (routine) => {
    const scheduledDate = parseISO(routine.scheduled_date);
    const now = new Date();
    
    if (routine.status === 'elapsed' || routine.status === 'completed') {
      return 'Elapsed';
    }
    
    const diffDays = Math.ceil((scheduledDate - now) / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 0) return 'Today';
    if (diffDays === 1) return 'Tomorrow';
    return `in ${diffDays} days - ${format(scheduledDate, 'EEEE')}`;
  };
  
  const allRoutines = routines.sort((a, b) => {
    const dateA = a.scheduled_date ? new Date(a.scheduled_date) : new Date();
    const dateB = b.scheduled_date ? new Date(b.scheduled_date) : new Date();
    return dateA - dateB;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={loadRoutines}>
    <div className="min-h-screen p-6 pb-24 dark:bg-[#121212]">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-serif text-3xl text-[#2C2C2C]">My Routine</h1>
        <button className="p-2">
          <Pencil className="w-5 h-5 text-[#3F5947]" />
        </button>
      </div>
      
      {/* Week Calendar */}
      <div className="mb-6">
        <div className="flex justify-between px-2 mb-2">
          {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, i) => (
            <span key={i} className="text-sm text-gray-400 w-10 text-center">{day}</span>
          ))}
        </div>
        <div className="flex justify-between">
          {weekDays.map((date, i) => {
            const isSelected = isSameDay(date, selectedDate);
            const hasRoutines = getRoutinesForDate(date).length > 0;
            const isPast = date < new Date() && !isSameDay(date, new Date());
            
            return (
              <button
                key={i}
                onClick={() => setSelectedDate(date)}
                className={`w-10 h-10 rounded-full flex flex-col items-center justify-center transition-colors ${
                  isSelected 
                    ? 'bg-gray-500 text-white' 
                    : isPast 
                      ? 'text-gray-300' 
                      : 'text-gray-700'
                }`}
              >
                <span className="text-sm font-medium">{format(date, 'd')}</span>
                {hasRoutines && !isSelected && (
                  <div className="flex gap-0.5 mt-0.5">
                    <div className="w-1 h-1 rounded-full bg-gray-400" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>
      
      {/* Scheduled Sessions */}
      <div className="mb-6">
        <h2 className="text-xs font-semibold text-gray-500 tracking-wide mb-4 flex items-center gap-2">
          SCHEDULED SESSIONS
          <span className="text-gray-300">~</span>
        </h2>
        
        {allRoutines.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <p>No scheduled sessions yet.</p>
            <p className="text-sm mt-2">Tap + to add your first ritual.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {allRoutines.map((routine) => (
              <div 
                key={routine.id}
                className={`p-4 rounded-xl ${
                  routine.status === 'elapsed' ? 'opacity-50' : 'bg-gray-50'
                }`}
              >
                <div className="flex gap-4">
                  <div className="text-sm text-gray-400 w-16">
                    {routine.scheduled_time || '7:00 AM'}
                  </div>
                  <div className="flex-1">
                    <p className="text-xs text-gray-400 mb-1">
                      {routine.content_duration || 5} min {routine.content_type || 'mantra'}
                    </p>
                    <h3 className="font-serif text-lg text-[#2C2C2C]">
                      {routine.content_title || 'Untitled Ritual'}
                    </h3>
                    <p className="text-sm text-gray-400 mt-1">
                      {getStatusText(routine)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* FAB */}
      <button
        onClick={() => setShowModal(true)}
        className="fixed bottom-24 right-6 w-14 h-14 bg-[#3F5947] rounded-full shadow-lg flex items-center justify-center z-40"
      >
        <Plus className="w-7 h-7 text-white" />
      </button>
      
      {/* Modal */}
      {showModal && (
        <div 
          className="fixed inset-0 bg-black/40 z-50 flex items-end"
          onClick={() => setShowModal(false)}
        >
          <div 
            className="bg-white rounded-t-3xl w-full p-6 space-y-4"
            onClick={e => e.stopPropagation()}
          >
            <button
              onClick={() => {
                setShowModal(false);
                navigate(createPageUrl('InstantRitual'));
              }}
              className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 rounded-xl transition-colors"
            >
              <Zap className="w-6 h-6" />
              <span className="font-medium">Instant ritual</span>
            </button>
            
            <button
              onClick={() => {
                setShowModal(false);
                navigate(createPageUrl('ScheduleRitual'));
              }}
              className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 rounded-xl transition-colors"
            >
              <CalendarPlus className="w-6 h-6" />
              <span className="font-medium">Schedule a new ritual</span>
            </button>
          </div>
        </div>
      )}
    </div>
    </PullToRefresh>
  );
}