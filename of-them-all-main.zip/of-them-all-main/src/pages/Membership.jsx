import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Check, Sparkles } from 'lucide-react';
import { format, addDays } from 'date-fns';

export default function Membership() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    loadProfile();
  }, []);
  
  const loadProfile = async () => {
    const profiles = await base44.entities.UserProfile.list();
    if (profiles.length > 0) {
      setProfile(profiles[0]);
    }
    setLoading(false);
  };
  
  const getMembershipEndDate = () => {
    if (profile?.membership_end_date) {
      return format(new Date(profile.membership_end_date), 'MMMM d');
    }
    return format(addDays(new Date(), 14), 'MMMM d');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <button onClick={() => navigate(-1)} className="mb-4">
        <ArrowLeft className="w-6 h-6 text-[#3F5947]" />
      </button>
      
      <h1 className="font-serif text-3xl text-[#2C2C2C] mb-6">Membership</h1>
      
      {/* Membership Card */}
      <div className="bg-gradient-to-r from-purple-500 to-purple-400 rounded-2xl p-6 mb-8 relative overflow-hidden">
        <Sparkles className="absolute top-4 right-4 w-8 h-8 text-white/50" />
        <Sparkles className="absolute top-8 right-12 w-4 h-4 text-white/30" />
        
        <p className="text-white/80 text-sm mb-2">Your current membership</p>
        <h2 className="font-serif text-4xl text-white mb-2">14 Days</h2>
        <p className="text-white/80 text-sm">Active • Until {getMembershipEndDate()}</p>
      </div>
      
      {/* Benefits */}
      <div className="bg-gradient-to-b from-purple-50 to-pink-50 rounded-2xl p-6 mb-8">
        <p className="text-gray-600 mb-6">
          Unlimited access to our best content with Premium features:
        </p>
        
        <div className="space-y-4">
          {[
            'Unlimited access to all well-being content',
            'Higher limits for content added to collection',
            'No limit on downloaded content'
          ].map((benefit, i) => (
            <div key={i} className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#2C2C2C] flex-shrink-0 mt-0.5" />
              <span className="text-[#2C2C2C]">{benefit}</span>
            </div>
          ))}
        </div>
      </div>
      
      {/* Extend Options */}
      <p className="text-gray-600 mb-4">To extend memberships, you can:</p>
      
      <div className="space-y-4">
        <button 
          onClick={() => navigate(createPageUrl('Market'))}
          className="w-full border-2 border-blue-400 rounded-2xl p-5 text-left hover:bg-blue-50 transition-colors"
        >
          <h3 className="font-semibold text-[#2C2C2C] mb-1">Subscribe to a plan</h3>
          <p className="text-sm text-gray-500">
            Subscription plan helps you to secure the best discount.
          </p>
        </button>
        
        <button 
          onClick={() => navigate(createPageUrl('Market'))}
          className="w-full border-2 border-blue-400 rounded-2xl p-5 text-left hover:bg-blue-50 transition-colors flex items-center gap-4"
        >
          <div className="flex-1">
            <h3 className="font-semibold text-[#2C2C2C] mb-1">Purchase with mask bundles</h3>
            <p className="text-sm text-gray-500">
              Complementary 30 or 60-day memberships available with mask bundles
            </p>
          </div>
          <div className="w-16 h-16 bg-gradient-to-br from-orange-200 to-blue-200 rounded-xl flex-shrink-0" />
        </button>
      </div>
    </div>
  );
}