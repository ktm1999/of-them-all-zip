import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Check, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import ProgressBar from '@/components/ui/ProgressBar';
import SelectionPill from '@/components/ui/SelectionPill';
import PrimaryButton from '@/components/ui/PrimaryButton';

const INTENTIONS = [
  'Feel calmer',
  'Build my confidence',
  'Glow up',
  'Have more fun',
  'Get more beauty sleep',
  'Strengthen my relationships'
];

const FEELINGS = {
  POSITIVE: [
    { emoji: '😊', label: 'Happy' },
    { emoji: '🙏', label: 'Grateful' },
    { emoji: '🧘', label: 'Calm' },
    { emoji: '🌈', label: 'Hopeful' },
    { emoji: '🎉', label: 'Excited' },
  ],
  'NEUTRAL / MIXED': [
    { emoji: '😐', label: 'Okay' },
    { emoji: '😴', label: 'Tired' },
    { emoji: '☁️', label: 'Numb' },
    { emoji: '💤', label: 'Bored' },
    { emoji: '😵', label: 'Overwhelmed' },
  ],
  NEGATIVE: [
    { emoji: '😢', label: 'Sad' },
    { emoji: '😰', label: 'Anxious' },
    { emoji: '😡', label: 'Angry' },
    { emoji: '😫', label: 'Stressed' },
    { emoji: '😔', label: 'Lonely' },
  ]
};

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const DURATIONS = [5, 10, 20, 30, 60];

export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [isEditing, setIsEditing] = useState(false);
  
  // Form state
  const [intentions, setIntentions] = useState([]);
  const [feelings, setFeelings] = useState([]);
  const [selectedDays, setSelectedDays] = useState([]);
  const [timeOfDay, setTimeOfDay] = useState('morning');
  const [duration, setDuration] = useState(10);
  const [saving, setSaving] = useState(false);
  
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('edit') === 'true') {
      setIsEditing(true);
      loadExistingProfile();
    }
  }, []);
  
  const loadExistingProfile = async () => {
    const profiles = await base44.entities.UserProfile.list();
    if (profiles.length > 0) {
      const profile = profiles[0];
      setIntentions(profile.intentions || []);
      setFeelings(profile.feelings || []);
      setSelectedDays(profile.schedule_days || []);
      setTimeOfDay(profile.schedule_time || 'morning');
      setDuration(profile.session_duration || 10);
    }
  };
  
  const toggleIntention = (intention) => {
    setIntentions(prev => 
      prev.includes(intention) 
        ? prev.filter(i => i !== intention)
        : [...prev, intention]
    );
  };
  
  const toggleFeeling = (feeling) => {
    setFeelings(prev => 
      prev.includes(feeling) 
        ? prev.filter(f => f !== feeling)
        : [...prev, feeling]
    );
  };
  
  const toggleDay = (day) => {
    setSelectedDays(prev => 
      prev.includes(day) 
        ? prev.filter(d => d !== day)
        : [...prev, day]
    );
  };
  
  const handleContinue = () => {
    if (step < 5) {
      setStep(step + 1);
    } else {
      handleComplete();
    }
  };
  
  const handleBack = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };
  
  const handleComplete = async () => {
    setSaving(true);
    
    const profiles = await base44.entities.UserProfile.list();
    const profileData = {
      intentions,
      feelings,
      schedule_days: selectedDays,
      schedule_time: timeOfDay,
      session_duration: duration,
      onboarding_completed: true,
      membership_tier: 'trial',
      membership_end_date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    };
    
    if (profiles.length > 0) {
      await base44.entities.UserProfile.update(profiles[0].id, profileData);
    } else {
      await base44.entities.UserProfile.create(profileData);
    }
    
    setSaving(false);
    navigate(createPageUrl('Space'));
  };
  
  const canContinue = () => {
    switch(step) {
      case 1: return intentions.length > 0;
      case 2: return feelings.length > 0;
      case 3: 
      case 4: return selectedDays.length > 0;
      case 5: return true;
      default: return false;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50/30 via-white to-pink-50/20 p-6">
      <AnimatePresence mode="wait">
        {/* Step 1: Intentions */}
        {step === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-md mx-auto"
          >
            <div className="mb-8">
              <ProgressBar currentStep={1} />
            </div>
            
            <h1 className="font-serif text-3xl text-[#2C2C2C] mb-8">
              My intention is to:
            </h1>
            
            <div className="space-y-3 mb-8">
              {INTENTIONS.map((intention) => (
                <SelectionPill
                  key={intention}
                  label={intention}
                  selected={intentions.includes(intention)}
                  onClick={() => toggleIntention(intention)}
                  fullWidth
                />
              ))}
            </div>
            
            <PrimaryButton onClick={handleContinue} disabled={!canContinue()}>
              Continue
            </PrimaryButton>
          </motion.div>
        )}
        
        {/* Step 2: Feelings */}
        {step === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-md mx-auto"
          >
            <div className="flex items-center gap-4 mb-8">
              <button onClick={handleBack} className="p-2 -ml-2">
                <ArrowLeft className="w-6 h-6 text-[#3F5947]" />
              </button>
              <div className="flex-1">
                <ProgressBar currentStep={2} />
              </div>
            </div>
            
            <h1 className="font-serif text-3xl text-[#2C2C2C] mb-8">
              Let's keep it real. How are you feeling?
            </h1>
            
            {Object.entries(FEELINGS).map(([category, items]) => (
              <div key={category} className="mb-6">
                <h3 className="text-xs font-semibold text-gray-500 tracking-wide mb-3">
                  {category}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {items.map((item) => (
                    <SelectionPill
                      key={item.label}
                      label={item.label}
                      emoji={item.emoji}
                      selected={feelings.includes(item.label)}
                      onClick={() => toggleFeeling(item.label)}
                      size="small"
                    />
                  ))}
                </div>
              </div>
            ))}
            
            <div className="mt-8">
              <PrimaryButton onClick={handleContinue} disabled={!canContinue()}>
                Continue
              </PrimaryButton>
            </div>
          </motion.div>
        )}
        
        {/* Step 3 & 4: Schedule */}
        {(step === 3 || step === 4) && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-md mx-auto"
          >
            <div className="flex items-center gap-4 mb-8">
              <button onClick={handleBack} className="p-2 -ml-2">
                <ArrowLeft className="w-6 h-6 text-[#3F5947]" />
              </button>
              <div className="flex-1">
                <ProgressBar currentStep={step} />
              </div>
            </div>
            
            <h1 className="font-serif text-3xl text-[#2C2C2C] mb-6">
              When do you plan to prioritize Me-Time?
            </h1>
            
            <div className="space-y-3 mb-6">
              {DAYS.map((day) => (
                <SelectionPill
                  key={day}
                  label={day}
                  selected={selectedDays.includes(day)}
                  onClick={() => toggleDay(day)}
                  fullWidth
                />
              ))}
            </div>
            
            {/* Time Selection */}
            <div className="bg-gray-50 rounded-2xl p-6 mb-6">
              <p className="text-gray-600 mb-4">When's your ideal time?</p>
              
              <div className="grid grid-cols-3 gap-4">
                {[
                  { key: 'morning', icon: '☀️', label: 'MORNING', time: '7:00 AM' },
                  { key: 'afternoon', icon: '🌤️', label: 'AFTERNOON', time: '12:00 PM' },
                  { key: 'evening', icon: '🌙', label: 'EVENING', time: '8:00 PM' },
                ].map((option) => (
                  <div key={option.key} className="text-center">
                    <div className="text-2xl mb-1">{option.icon}</div>
                    <div className="text-xs font-semibold text-gray-500 mb-2">{option.label}</div>
                    <div className={`px-3 py-2 rounded-full text-sm font-medium ${
                      timeOfDay === option.key ? 'bg-black text-white' : 'bg-gray-200 text-gray-600'
                    }`}>
                      {option.time}
                    </div>
                    <button
                      onClick={() => setTimeOfDay(option.key)}
                      className={`mt-2 w-10 h-5 rounded-full transition-colors ${
                        timeOfDay === option.key ? 'bg-black' : 'bg-gray-300'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-full bg-white transition-transform ${
                        timeOfDay === option.key ? 'translate-x-5' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Duration */}
            <div className="mb-8">
              <p className="text-xs font-semibold text-gray-500 tracking-wide mb-3">
                HOW LONG FOR EACH SESSION?
              </p>
              <div className="flex flex-wrap gap-2">
                {DURATIONS.map((d) => (
                  <SelectionPill
                    key={d}
                    label={d === 60 ? '1 hour' : `${d} min`}
                    selected={duration === d}
                    onClick={() => setDuration(d)}
                    size="small"
                  />
                ))}
              </div>
            </div>
            
            <PrimaryButton onClick={handleContinue} disabled={!canContinue()}>
              Continue
            </PrimaryButton>
          </motion.div>
        )}
        
        {/* Step 5: Completion */}
        {step === 5 && (
          <motion.div
            key="step5"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="max-w-md mx-auto flex flex-col items-center pt-12"
          >
            {/* Success Icon */}
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-purple-300 to-purple-100 flex items-center justify-center mb-8">
              <Check className="w-12 h-12 text-white" strokeWidth={3} />
            </div>
            
            <h1 className="font-serif text-3xl text-[#2C2C2C] text-center mb-8">
              Your new self-care journey is ready!
            </h1>
            
            {/* Feature Cards */}
            <div className="w-full space-y-4 mb-8">
              <div className="bg-gray-50 rounded-2xl p-5 flex items-start gap-4">
                <Sparkles className="w-6 h-6 text-gray-600 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <h3 className="font-semibold text-[#2C2C2C] mb-1">Curating your feeds</h3>
                  <p className="text-sm text-gray-500 leading-relaxed">
                    A personalized journey made just for you. Tailored to help you unlock the highest version of yourself.
                  </p>
                </div>
                <Check className="w-5 h-5 text-gray-600" />
              </div>
              
              <div className="bg-gray-50 rounded-2xl p-5 flex items-start gap-4">
                <span className="text-xl">∞</span>
                <div className="flex-1">
                  <h3 className="font-semibold text-[#2C2C2C] mb-1">My Routine</h3>
                  <p className="text-sm text-gray-500">My current self-care schedule</p>
                </div>
                <Check className="w-5 h-5 text-gray-600" />
              </div>
            </div>
            
            <PrimaryButton onClick={handleComplete} disabled={saving}>
              {saving ? 'Saving...' : 'Continue'}
            </PrimaryButton>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}