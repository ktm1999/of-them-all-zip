import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Heart, Share2, Play, MoreHorizontal } from 'lucide-react';
import PrimaryButton from '@/components/ui/PrimaryButton';

export default function RitualDetail() {
  const navigate = useNavigate();
  const [content, setContent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isLiked, setIsLiked] = useState(false);
  
  useEffect(() => {
    loadContent();
  }, []);
  
  const loadContent = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const contentId = urlParams.get('id');
    
    if (contentId) {
      const contentList = await base44.entities.Content.filter({ id: contentId });
      if (contentList.length > 0) {
        setContent(contentList[0]);
        
        // Check if liked
        const collections = await base44.entities.Collection.filter({ 
          content_id: contentId,
          collection_type: 'liked'
        });
        setIsLiked(collections.length > 0);
        
        // Add to recent
        await addToRecent(contentList[0]);
      }
    }
    setLoading(false);
  };
  
  const addToRecent = async (contentItem) => {
    // Check if already in recent
    const existing = await base44.entities.Collection.filter({
      content_id: contentItem.id,
      collection_type: 'recent'
    });
    
    if (existing.length === 0) {
      await base44.entities.Collection.create({
        content_id: contentItem.id,
        content_title: contentItem.title,
        content_type: contentItem.type,
        content_duration: contentItem.duration_minutes,
        content_gradient_start: contentItem.gradient_start,
        content_gradient_end: contentItem.gradient_end,
        collection_type: 'recent'
      });
    }
  };
  
  const handleLike = async () => {
    // Optimistic update
    const prevLiked = isLiked;
    setIsLiked(!isLiked);

    if (prevLiked) {
      const collections = await base44.entities.Collection.filter({ 
        content_id: content.id,
        collection_type: 'liked'
      });
      if (collections.length > 0) {
        await base44.entities.Collection.delete(collections[0].id);
      }
    } else {
      await base44.entities.Collection.create({
        content_id: content.id,
        content_title: content.title,
        content_type: content.type,
        content_duration: content.duration_minutes,
        content_gradient_start: content.gradient_start,
        content_gradient_end: content.gradient_end,
        collection_type: 'liked'
      });
    }
  };
  
  const handlePlay = () => {
    navigate(createPageUrl('Player') + `?id=${content.id}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!content) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-gray-500">Content not found</p>
      </div>
    );
  }

  const gradientStart = content.gradient_start || '#6B5B7F';
  const gradientEnd = content.gradient_end || '#4A5F7A';

  return (
    <div className="min-h-screen flex flex-col">
      {/* Hero Section */}
      <div 
        className="h-[45vh] relative flex items-center justify-center"
        style={{ background: `linear-gradient(180deg, ${gradientStart}, ${gradientEnd})` }}
      >
        <button 
          onClick={() => navigate(-1)}
          className="absolute top-6 left-6 text-white"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        
        {/* Meditation Icon */}
        <svg 
          viewBox="0 0 64 64" 
          className="w-24 h-24 text-white/80"
          fill="currentColor"
        >
          <circle cx="32" cy="16" r="8" />
          <path d="M20 52 Q32 44 44 52 L48 58 Q32 50 16 58 Z" />
          <ellipse cx="32" cy="36" rx="12" ry="8" />
        </svg>
      </div>
      
      {/* Content Section */}
      <div className="flex-1 bg-white -mt-6 rounded-t-3xl p-6 relative">
        <button className="absolute top-6 right-6">
          <MoreHorizontal className="w-6 h-6 text-gray-400" />
        </button>
        
        <p className="text-gray-500 text-sm mb-2">
          {content.type?.charAt(0).toUpperCase() + content.type?.slice(1)} · {content.duration_minutes} min
        </p>
        
        <h1 className="font-serif text-2xl text-[#2C2C2C] mb-4 pr-8">
          {content.title}
        </h1>
        
        <p className="text-gray-600 leading-relaxed mb-6">
          {content.description}
        </p>
        
        {/* Tags */}
        {content.tags && content.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-8">
            {content.tags.map((tag, index) => (
              <span 
                key={index}
                className="px-4 py-2 bg-gray-100 rounded-full text-sm text-gray-600"
              >
                {tag}
              </span>
            ))}
          </div>
        )}
        
        {/* Bottom Actions */}
        <div className="flex items-center gap-4 mt-auto pt-4">
          <button 
            onClick={handleLike}
            className="w-14 h-14 rounded-full border border-gray-200 flex items-center justify-center"
          >
            <Heart 
              className={`w-6 h-6 ${isLiked ? 'text-red-500 fill-red-500' : 'text-gray-600'}`} 
            />
          </button>
          
          <button className="w-14 h-14 rounded-full border border-gray-200 flex items-center justify-center">
            <Share2 className="w-6 h-6 text-gray-600" />
          </button>
          
          <button
            onClick={handlePlay}
            className="flex-1 bg-[#3F5947] text-white py-4 px-6 rounded-full font-semibold flex items-center justify-center gap-2"
          >
            <Play className="w-5 h-5" fill="white" />
            Play
          </button>
        </div>
      </div>
    </div>
  );
}