import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ChevronRight } from 'lucide-react';

const FAQS = [
  { question: 'How do I cancel my subscription?', answer: 'You can cancel your subscription from the Membership section in your profile.' },
  { question: 'How do I download content?', answer: 'Premium members can download content by tapping the download icon on any ritual.' },
  { question: 'How do I contact support?', answer: 'You can reach us at support@ofthemall.com' },
  { question: 'What payment methods do you accept?', answer: 'We accept all major credit cards and Apple Pay.' },
];

export default function HelpCenter() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <button onClick={() => navigate(-1)} className="mb-4">
        <ArrowLeft className="w-6 h-6 text-[#3F5947]" />
      </button>
      
      <h1 className="font-serif text-3xl text-[#2C2C2C] mb-6">Help Center</h1>
      
      {/* FAQ List */}
      <div className="space-y-4">
        {FAQS.map((faq, i) => (
          <details key={i} className="group">
            <summary className="flex items-center justify-between py-4 cursor-pointer list-none">
              <span className="font-medium text-[#2C2C2C]">{faq.question}</span>
              <ChevronRight className="w-5 h-5 text-gray-400 group-open:rotate-90 transition-transform" />
            </summary>
            <p className="pb-4 text-gray-500 pl-4">{faq.answer}</p>
          </details>
        ))}
      </div>
      
      {/* Contact */}
      <div className="mt-12 text-center">
        <p className="text-gray-500 mb-2">Still need help?</p>
        <a href="mailto:support@ofthemall.com" className="text-[#3F5947] font-medium">
          Contact Support
        </a>
      </div>
    </div>
  );
}