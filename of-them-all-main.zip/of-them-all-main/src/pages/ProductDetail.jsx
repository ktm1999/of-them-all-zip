import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { X, ShoppingBag } from 'lucide-react';
import PrimaryButton from '@/components/ui/PrimaryButton';

export default function ProductDetail() {
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  
  useEffect(() => {
    loadProduct();
  }, []);
  
  const loadProduct = async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');
    
    const [products, cartItems] = await Promise.all([
      base44.entities.Product.list(),
      base44.entities.CartItem.list()
    ]);
    
    // Find product or use default
    const found = products.find(p => p.id === productId);
    
    if (found) {
      setProduct(found);
    } else {
      // Default product based on ID
      const defaults = {
        'bi-weekly': {
          id: 'bi-weekly',
          name: 'BI-WEEKLY BUNDLE',
          price: 49.99,
          type: 'bundle',
          benefits: [
            '4 Glowing & lifting sheet mask',
            '4 Cooling & calming sheet masks',
            '14 day free trial + 30 day complimentary membership'
          ]
        },
        'monthly': {
          id: 'monthly',
          name: 'MONTHLY BUNDLE',
          price: 79.99,
          type: 'bundle',
          benefits: [
            '9 Glowing & lifting sheet masks',
            '9 Cooling & calming sheet masks',
            '14 day free trial + 60 day complimentary membership'
          ]
        }
      };
      setProduct(defaults[productId] || defaults['bi-weekly']);
    }
    
    setCartCount(cartItems.reduce((sum, item) => sum + (item.quantity || 1), 0));
    setLoading(false);
  };
  
  const handleAddToCart = async () => {
    if (!product) return;
    
    setAdding(true);
    
    // Check if already in cart
    const existingItems = await base44.entities.CartItem.filter({ 
      product_id: product.id 
    });
    
    if (existingItems.length > 0) {
      await base44.entities.CartItem.update(existingItems[0].id, {
        quantity: (existingItems[0].quantity || 1) + 1
      });
    } else {
      await base44.entities.CartItem.create({
        product_id: product.id,
        product_name: product.name,
        product_price: product.price,
        quantity: 1
      });
    }
    
    setCartCount(prev => prev + 1);
    setAdding(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div
      className="min-h-screen bg-white dark:bg-[#121212]"
      style={{
        paddingTop: 'calc(1.5rem + env(safe-area-inset-top))',
        paddingBottom: 'calc(1.5rem + env(safe-area-inset-bottom))',
        paddingLeft: '1.5rem',
        paddingRight: '1.5rem',
      }}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button onClick={() => navigate(-1)}>
          <X className="w-6 h-6" />
        </button>
        
        <button 
          onClick={() => navigate(createPageUrl('Cart'))}
          className="w-12 h-12 bg-[#3F5947] rounded-full flex items-center justify-center relative"
        >
          <ShoppingBag className="w-5 h-5 text-white" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </button>
      </div>
      
      {/* Product Image */}
      <div className="flex justify-center mb-8">
        <div className="w-64 h-64 bg-gradient-to-br from-purple-100 to-pink-50 rounded-2xl flex items-center justify-center">
          <div className="w-48 h-48 bg-white rounded-xl shadow-lg flex items-center justify-center transform rotate-6">
            <div className="text-center">
              <div className="w-12 h-12 mx-auto mb-2 border border-gray-200 rounded-full flex items-center justify-center">
                <span className="text-xs text-gray-400">OTA</span>
              </div>
              <div className="h-8 bg-gradient-to-r from-purple-200 to-pink-200 rounded" />
            </div>
          </div>
        </div>
      </div>
      
      {/* Product Info */}
      <h1 className="font-serif text-2xl text-[#2C2C2C] mb-2">{product?.name}</h1>
      <p className="font-serif text-xl text-[#2C2C2C] mb-6">${product?.price}</p>
      
      {/* Benefits */}
      {product?.benefits && (
        <div className="mb-8">
          <h2 className="font-semibold text-[#2C2C2C] mb-3">Bundle includes:</h2>
          <ul className="space-y-2">
            {product.benefits.map((benefit, i) => (
              <li key={i} className="text-gray-600">- {benefit}</li>
            ))}
          </ul>
        </div>
      )}
      
      {/* Mask Sheets Preview */}
      <div className="mb-8">
        <h2 className="font-semibold text-[#2C2C2C] mb-3">Mask Sheets</h2>
        <div className="flex gap-4">
          <div className="w-24 h-24 bg-gradient-to-br from-orange-200 to-pink-200 rounded-xl" />
          <div className="w-24 h-24 bg-gradient-to-br from-blue-300 to-blue-200 rounded-xl" />
        </div>
      </div>
      
      {/* Add to Cart */}
      <PrimaryButton onClick={handleAddToCart} disabled={adding}>
        {adding ? 'Adding...' : 'Add to Cart'}
      </PrimaryButton>
    </div>
  );
}