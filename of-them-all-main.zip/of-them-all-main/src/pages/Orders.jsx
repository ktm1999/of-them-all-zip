import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function Orders() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen p-6">
      {/* Header */}
      <button onClick={() => navigate(-1)} className="mb-4">
        <ArrowLeft className="w-6 h-6 text-[#3F5947]" />
      </button>
      
      <h1 className="font-serif text-3xl text-[#2C2C2C] mb-6">My Orders</h1>
      
      {/* Empty State */}
      <div className="text-center py-20">
        <p className="font-serif text-xl text-gray-400">You have no orders yet.</p>
      </div>
    </div>
  );
}