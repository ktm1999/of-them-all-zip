import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Settings, Target, Bookmark, ShoppingBag, HelpCircle, ChevronRight } from 'lucide-react';

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    loadData();
  }, []);
  
  const loadData = async () => {
    try {
      const [userData, profiles] = await Promise.all([
        base44.auth.me(),
        base44.entities.UserProfile.list()
      ]);
      
      setUser(userData);
      if (profiles.length > 0) {
        setProfile(profiles[0]);
      }
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };
  
  const getInitial = () => {
    if (user?.full_name) {
      return user.full_name.charAt(0).toUpperCase();
    }
    if (user?.email) {
      return user.email.charAt(0).toUpperCase();
    }
    return 'U';
  };
  
  const getDisplayName = () => {
    if (user?.full_name) {
      const parts = user.full_name.split(' ');
      if (parts.length > 1) {
        return `${parts[0]} ${parts[1].charAt(0)}.`;
      }
      return user.full_name;
    }
    return 'User';
  };

  const menuItems = [
    { icon: Settings, label: 'My Membership', page: 'Membership' },
    { icon: Target, label: 'My Goal', page: 'Goals' },
    { icon: Bookmark, label: 'My Collections', page: 'Collections' },
    { icon: ShoppingBag, label: 'My Orders', page: 'Orders' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      {/* Profile Header */}
      <div className="flex items-center gap-4 mb-10">
        <div className="w-20 h-20 rounded-full bg-[#C8D5C8] flex items-center justify-center">
          <span className="text-white font-serif text-3xl">{getInitial()}</span>
        </div>
        <div>
          <h1 className="font-serif text-2xl text-[#2C2C2C]">{getDisplayName()}</h1>
          <Link 
            to={createPageUrl('Account')}
            className="text-gray-500 hover:text-gray-700"
          >
            My account &gt;
          </Link>
        </div>
      </div>
      
      {/* Menu Items */}
      <div className="space-y-2 mb-8">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.label}
              to={createPageUrl(item.page)}
              className="flex items-center gap-4 py-4 hover:bg-gray-50 rounded-xl transition-colors"
            >
              <Icon className="w-6 h-6 text-[#2C2C2C]" />
              <span className="flex-1 font-medium text-[#2C2C2C]">{item.label}</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </Link>
          );
        })}
      </div>
      
      {/* Help Center */}
      <div className="pt-4 border-t border-gray-100">
        <Link
          to={createPageUrl('HelpCenter')}
          className="flex items-center gap-4 py-4 hover:bg-gray-50 rounded-xl transition-colors"
        >
          <HelpCircle className="w-6 h-6 text-[#2C2C2C]" />
          <span className="flex-1 font-medium text-[#2C2C2C]">Help Center</span>
          <ChevronRight className="w-5 h-5 text-gray-400" />
        </Link>
      </div>
    </div>
  );
}