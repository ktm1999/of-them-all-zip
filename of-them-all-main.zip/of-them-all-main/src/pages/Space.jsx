import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Search, X } from 'lucide-react';
import ContentCard from '@/components/cards/ContentCard';
import QuoteCard from '@/components/cards/QuoteCard';
import ArticleCard from '@/components/cards/ArticleCard';
import PullToRefresh from '@/components/PullToRefresh';

const CATEGORIES = [
  { key: 'chill_mode', label: 'Chill Mode', bg: 'bg-blue-100/70' },
  { key: 'energize', label: 'Energize', bg: 'bg-gray-100' },
  { key: 'exhale', label: 'Exhale', bg: 'bg-amber-50' },
  { key: 'rise_shine', label: 'Rise & Shine', bg: 'bg-pink-100/70' },
  { key: 'confidence', label: 'Confidence', bg: 'bg-gray-100' },
  { key: 'lights_out', label: 'Lights Out', bg: 'bg-purple-100/70' },
];

export default function Space() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showWelcome, setShowWelcome] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState(null);
  
  useEffect(() => {
    loadData();
  }, []);
  
  const loadData = async () => {
    setLoading(true);
    
    // Check if onboarding is completed
    const profiles = await base44.entities.UserProfile.list();
    if (profiles.length === 0 || !profiles[0].onboarding_completed) {
      navigate(createPageUrl('Onboarding'));
      return;
    }
    setProfile(profiles[0]);
    
    // Load content
    const contentList = await base44.entities.Content.list();
    setContent(contentList);
    
    setLoading(false);
  };
  
  const filteredContent = selectedCategory 
    ? content.filter(c => c.category === selectedCategory)
    : content;
  
  const handleCategoryClick = (categoryKey) => {
    if (selectedCategory === categoryKey) {
      setSelectedCategory(null);
    } else {
      setSelectedCategory(categoryKey);
    }
  };
  
  const handleContentClick = (item) => {
    navigate(createPageUrl('RitualDetail') + `?id=${item.id}`);
  };
  
  const handlePlayClick = (item) => {
    navigate(createPageUrl('Player') + `?id=${item.id}`);
  };
  
  const pageTitle = selectedCategory 
    ? CATEGORIES.find(c => c.key === selectedCategory)?.label 
    : 'Space';

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={loadData}>
    <div className="min-h-screen p-6 dark:bg-[#121212]">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-serif text-3xl text-[#2C2C2C]">{pageTitle}</h1>
        <button className="p-2">
          <Search className="w-6 h-6 text-[#2C2C2C]" />
        </button>
      </div>
      
      {/* Welcome Banner */}
      {showWelcome && !selectedCategory && (
        <div className="bg-yellow-50 rounded-xl p-4 mb-6 relative">
          <button 
            onClick={() => setShowWelcome(false)}
            className="absolute top-3 right-3"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
          <p className="text-sm text-[#2C2C2C] pr-6">
            Welcome onboard! Your self care journey has started. For 14 days from today, enjoy the complete membership experience - all on us.
          </p>
          <button className="text-sm font-semibold text-[#2C2C2C] underline mt-2">
            More about Memberships
          </button>
        </div>
      )}
      
      {/* Category Pills */}
      <div className="grid grid-cols-3 gap-2 mb-6">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.key}
            onClick={() => handleCategoryClick(cat.key)}
            className={`${cat.bg} rounded-xl py-4 px-3 text-center transition-all ${
              selectedCategory === cat.key ? 'ring-2 ring-gray-400' : ''
            }`}
          >
            <span className="text-sm font-medium text-[#2C2C2C]">{cat.label}</span>
          </button>
        ))}
      </div>
      
      {/* Content Section */}
      <div className="mb-4">
        <h2 className="text-xs font-semibold text-gray-500 tracking-wide mb-4">
          {selectedCategory ? CATEGORIES.find(c => c.key === selectedCategory)?.label : 'RECOMMENDED'}
        </h2>
        
        <div className="space-y-4">
          {filteredContent.map((item) => {
            if (item.type === 'quote') {
              return (
                <QuoteCard 
                  key={item.id} 
                  content={item} 
                  onClick={() => handleContentClick(item)}
                />
              );
            }
            if (item.type === 'article') {
              return (
                <ArticleCard 
                  key={item.id} 
                  content={item} 
                  onClick={() => handleContentClick(item)}
                />
              );
            }
            return (
              <ContentCard 
                key={item.id} 
                content={item} 
                onClick={() => handleContentClick(item)}
                onPlayClick={() => handlePlayClick(item)}
              />
            );
          })}
          
          {filteredContent.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              No content available in this category yet.
            </div>
          )}
        </div>
      </div>
    </div>
    </PullToRefresh>
  );
}