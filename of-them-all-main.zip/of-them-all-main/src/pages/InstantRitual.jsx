import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { ArrowLeft, Search, CheckCircle2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import PrimaryButton from '@/components/ui/PrimaryButton';

export default function InstantRitual() {
  const navigate = useNavigate();
  const [content, setContent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState(null);
  
  useEffect(() => {
    loadContent();
  }, []);
  
  const loadContent = async () => {
    const data = await base44.entities.Content.filter({ type: 'mantra' });
    setContent(data);
    setLoading(false);
  };
  
  const filteredContent = content.filter(c => 
    c.title?.toLowerCase().includes(search.toLowerCase())
  );
  
  const handleStart = () => {
    if (selectedId) {
      navigate(createPageUrl('Player') + `?id=${selectedId}`);
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <div className="p-6 pb-0">
        <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-6" />
        
        <button 
          onClick={() => navigate(-1)}
          className="mb-4"
        >
          <ArrowLeft className="w-6 h-6 text-[#3F5947]" />
        </button>
        
        <h1 className="font-serif text-3xl text-[#2C2C2C] mb-6">Instant ritual</h1>
        
        {/* Search */}
        <div className="relative mb-6">
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search"
            className="pl-4 pr-10 py-3 rounded-full bg-gray-100 border-0"
          />
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        </div>
      </div>
      
      {/* Content List */}
      <div className="flex-1 overflow-auto px-6">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-8 h-8 border-2 border-[#3F5947] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="space-y-4">
            {filteredContent.map((item) => (
              <button
                key={item.id}
                onClick={() => setSelectedId(item.id)}
                className={`w-full flex items-center gap-4 p-4 rounded-xl transition-colors ${
                  selectedId === item.id ? 'bg-gray-50' : 'hover:bg-gray-50'
                }`}
              >
                {/* Thumbnail */}
                <div 
                  className="w-20 h-20 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ 
                    background: `linear-gradient(135deg, ${item.gradient_start || '#F4B084'}, ${item.gradient_end || '#FDD9C4'})` 
                  }}
                >
                  <svg 
                    viewBox="0 0 64 64" 
                    className="w-10 h-10 text-white/80"
                    fill="currentColor"
                  >
                    <circle cx="32" cy="16" r="6" />
                    <path d="M20 48 Q32 42 44 48 L46 52 Q32 46 18 52 Z" />
                    <ellipse cx="32" cy="34" rx="10" ry="7" />
                  </svg>
                </div>
                
                {/* Info */}
                <div className="flex-1 text-left">
                  <p className="text-xs text-gray-400 mb-1">
                    {item.type} · {item.duration_minutes} min
                  </p>
                  <h3 className="font-serif text-lg text-[#2C2C2C]">{item.title}</h3>
                </div>
                
                {/* Selection Indicator */}
                {selectedId === item.id && (
                  <CheckCircle2 className="w-6 h-6 text-[#3F5947] flex-shrink-0" />
                )}
              </button>
            ))}
          </div>
        )}
      </div>
      
      {/* Bottom CTA */}
      <div className="p-6 pt-4">
        <PrimaryButton 
          onClick={handleStart}
          disabled={!selectedId}
        >
          Start ritual
        </PrimaryButton>
      </div>
    </div>
  );
}